// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//
// Modified for Chrome 134: File operations done locally instead of via IPC,
// since browser-side Flash file host doesn't exist anymore.

#pragma allow_unsafe_buffers

#include "ppapi/proxy/flash_file_resource.h"

#include <stddef.h>

#include "base/files/file.h"
#include "base/files/file_enumerator.h"
#include "base/files/file_path.h"
#include "base/files/file_util.h"
#include "base/path_service.h"
#include "ipc/ipc_message.h"
#include "ppapi/c/pp_errors.h"
#include "ppapi/c/ppb_file_io.h"
#include "ppapi/proxy/ppapi_messages.h"
#include "ppapi/shared_impl/file_type_conversion.h"
#include "ppapi/shared_impl/scoped_pp_var.h"
#include "ppapi/shared_impl/time_conversion.h"
#include "ppapi/shared_impl/var.h"
#include "ppapi/thunk/enter.h"
#include "ppapi/thunk/ppb_file_ref_api.h"

namespace ppapi {
namespace proxy {

namespace {

// Get the Flash data directory (userData/Pepper Data/Shockwave Flash/WritableRoot)
base::FilePath GetFlashDataDir() {
  base::FilePath exe_dir;
  base::PathService::Get(base::DIR_EXE, &exe_dir);
  // Navigate from exe dir to the userData equivalent
  // For Electron: exe is in dist/, userData is in AppData/Roaming/<productName>
  // The Pepper Data should be relative to userData
  // But since we don't have access to userData here, use a path relative to exe
  // Actually, Flash trust files need to be in the Pepper Data dir
  // Let's check multiple locations

  // First try: next to the Flash DLL
  base::FilePath flash_dir = exe_dir.Append(L"resources")
      .Append(L"app").Append(L"pepperflash");
  if (base::DirectoryExists(flash_dir))
    return flash_dir;

  return exe_dir;
}

std::string GetPathFromFileRef(PP_Resource file_ref) {
  thunk::EnterResourceNoLock<thunk::PPB_FileRef_API> enter(file_ref, true);
  if (enter.failed())
    return std::string();
  if (enter.object()->GetFileSystemType() != PP_FILESYSTEMTYPE_EXTERNAL)
    return std::string();
  ScopedPPVar var(ScopedPPVar::PassRef(), enter.object()->GetAbsolutePath());
  StringVar* string_var = StringVar::FromPPVar(var.get());
  if (!string_var)
    return std::string();
  return string_var->value();
}

base::FilePath ResolvePath(const std::string& path,
                            bool is_module_local) {
  if (is_module_local) {
    return GetFlashDataDir().Append(base::FilePath::FromUTF8Unsafe(path));
  }
  return base::FilePath::FromUTF8Unsafe(path);
}

}  // namespace

FlashFileResource::FlashFileResource(Connection connection,
                                     PP_Instance instance)
    : PluginResource(connection, instance) {
  SendCreate(BROWSER, PpapiHostMsg_FlashFile_Create());
}

FlashFileResource::~FlashFileResource() {
}

thunk::PPB_Flash_File_API* FlashFileResource::AsPPB_Flash_File_API() {
  return this;
}

int32_t FlashFileResource::OpenFile(PP_Instance /*instance*/,
                                    const char* path,
                                    int32_t mode,
                                    PP_FileHandle* file) {
  if (!path || !file)
    return PP_ERROR_BADARGUMENT;

  base::FilePath full_path = ResolvePath(path, true);

  int flags = 0;
  if (mode & PP_FILEOPENFLAG_READ)
    flags |= base::File::FLAG_OPEN | base::File::FLAG_READ;
  if (mode & PP_FILEOPENFLAG_WRITE) {
    flags |= base::File::FLAG_WRITE;
    if (mode & PP_FILEOPENFLAG_CREATE)
      flags |= base::File::FLAG_CREATE_ALWAYS;
    else
      flags |= base::File::FLAG_OPEN;
  }
  if (flags == 0)
    flags = base::File::FLAG_OPEN | base::File::FLAG_READ;

  base::File base_file(full_path, flags);
  if (!base_file.IsValid())
    return PP_ERROR_FILENOTFOUND;

  *file = base_file.TakePlatformFile();
  return PP_OK;
}

int32_t FlashFileResource::RenameFile(PP_Instance /*instance*/,
                                      const char* path_from,
                                      const char* path_to) {
  base::FilePath from = ResolvePath(path_from, true);
  base::FilePath to = ResolvePath(path_to, true);
  return base::Move(from, to) ? PP_OK : PP_ERROR_FAILED;
}

int32_t FlashFileResource::DeleteFileOrDir(PP_Instance /*instance*/,
                                           const char* path,
                                           PP_Bool recursive) {
  base::FilePath full_path = ResolvePath(path, true);
  bool success = PP_ToBool(recursive)
      ? base::DeletePathRecursively(full_path)
      : base::DeleteFile(full_path);
  return success ? PP_OK : PP_ERROR_FAILED;
}

int32_t FlashFileResource::CreateDir(PP_Instance /*instance*/,
                                     const char* path) {
  base::FilePath full_path = ResolvePath(path, true);
  return base::CreateDirectory(full_path) ? PP_OK : PP_ERROR_FAILED;
}

int32_t FlashFileResource::QueryFile(PP_Instance /*instance*/,
                                     const char* path,
                                     PP_FileInfo* info) {
  if (!path || !info)
    return PP_ERROR_BADARGUMENT;

  base::FilePath full_path = ResolvePath(path, true);
  base::File::Info file_info;
  if (!base::GetFileInfo(full_path, &file_info))
    return PP_ERROR_FILENOTFOUND;

  info->size = file_info.size;
  info->creation_time = TimeToPPTime(file_info.creation_time);
  info->last_access_time = TimeToPPTime(file_info.last_accessed);
  info->last_modified_time = TimeToPPTime(file_info.last_modified);
  info->system_type = PP_FILESYSTEMTYPE_EXTERNAL;
  info->type = file_info.is_directory ? PP_FILETYPE_DIRECTORY : PP_FILETYPE_REGULAR;
  return PP_OK;
}

int32_t FlashFileResource::GetDirContents(PP_Instance /*instance*/,
                                          const char* path,
                                          PP_DirContents_Dev** contents) {
  if (!path || !contents)
    return PP_ERROR_BADARGUMENT;

  base::FilePath full_path = ResolvePath(path, true);
  base::FileEnumerator enumerator(full_path, false,
      base::FileEnumerator::FILES | base::FileEnumerator::DIRECTORIES);

  std::vector<std::pair<std::string, bool>> entries;
  for (base::FilePath name = enumerator.Next(); !name.empty();
       name = enumerator.Next()) {
    base::FileEnumerator::FileInfo info = enumerator.GetInfo();
    entries.push_back({name.BaseName().AsUTF8Unsafe(), info.IsDirectory()});
  }

  *contents = new PP_DirContents_Dev;
  (*contents)->count = static_cast<int32_t>(entries.size());
  (*contents)->entries = new PP_DirEntry_Dev[entries.size()];
  for (size_t i = 0; i < entries.size(); i++) {
    char* name_copy = new char[entries[i].first.size() + 1];
    memcpy(name_copy, entries[i].first.c_str(), entries[i].first.size() + 1);
    (*contents)->entries[i].name = name_copy;
    (*contents)->entries[i].is_dir = PP_FromBool(entries[i].second);
  }
  return PP_OK;
}

void FlashFileResource::FreeDirContents(PP_Instance /*instance*/,
                                        PP_DirContents_Dev* contents) {
  for (int32_t i = 0; i < contents->count; ++i)
    delete[] contents->entries[i].name;
  delete[] contents->entries;
  delete contents;
}

int32_t FlashFileResource::CreateTemporaryFile(PP_Instance /*instance*/,
                                               PP_FileHandle* file) {
  if (!file)
    return PP_ERROR_BADARGUMENT;

  base::FilePath temp_path;
  if (!base::CreateTemporaryFile(&temp_path))
    return PP_ERROR_FAILED;

  base::File temp_file(temp_path,
      base::File::FLAG_OPEN | base::File::FLAG_READ | base::File::FLAG_WRITE |
      base::File::FLAG_DELETE_ON_CLOSE);
  if (!temp_file.IsValid())
    return PP_ERROR_FAILED;

  *file = temp_file.TakePlatformFile();
  return PP_OK;
}

int32_t FlashFileResource::OpenFileRef(PP_Instance /*instance*/,
                                       PP_Resource file_ref,
                                       int32_t mode,
                                       PP_FileHandle* file) {
  std::string path = GetPathFromFileRef(file_ref);
  if (path.empty() || !file)
    return PP_ERROR_BADARGUMENT;

  base::FilePath full_path = base::FilePath::FromUTF8Unsafe(path);
  base::File base_file(full_path,
      base::File::FLAG_OPEN | base::File::FLAG_READ);
  if (!base_file.IsValid())
    return PP_ERROR_FILENOTFOUND;

  *file = base_file.TakePlatformFile();
  return PP_OK;
}

int32_t FlashFileResource::QueryFileRef(PP_Instance /*instance*/,
                                        PP_Resource file_ref,
                                        PP_FileInfo* info) {
  std::string path = GetPathFromFileRef(file_ref);
  if (path.empty() || !info)
    return PP_ERROR_BADARGUMENT;

  base::FilePath full_path = base::FilePath::FromUTF8Unsafe(path);
  base::File::Info file_info;
  if (!base::GetFileInfo(full_path, &file_info))
    return PP_ERROR_FILENOTFOUND;

  info->size = file_info.size;
  info->creation_time = TimeToPPTime(file_info.creation_time);
  info->last_access_time = TimeToPPTime(file_info.last_accessed);
  info->last_modified_time = TimeToPPTime(file_info.last_modified);
  info->system_type = PP_FILESYSTEMTYPE_EXTERNAL;
  info->type = file_info.is_directory ? PP_FILETYPE_DIRECTORY : PP_FILETYPE_REGULAR;
  return PP_OK;
}

}  // namespace proxy
}  // namespace ppapi
